#ifndef INDEX_H
#define INDEX_H

#include <stdint.h>
#include "object.h"

#define MAX_ENTRIES 1024

typedef struct {
    char path[256];
    uint32_t mode;
    ObjectID hash;
    uint64_t mtime_sec;
    uint32_t size;
} IndexEntry;

typedef struct {
    IndexEntry entries[MAX_ENTRIES];
    int count;
} Index;

// Core functions
int index_load(Index *index);
int index_save(Index *index);
int index_add(Index *index, const char *path);
int index_remove(Index *index, const char *path);
IndexEntry* index_find(Index *index, const char *path);
int index_status(const Index *index);

#endif