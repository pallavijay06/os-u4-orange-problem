#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "index.h"

#define INDEX_FILE ".pes/index"

// Load index from file
int index_load(Index *index) {
    FILE *f = fopen(INDEX_FILE, "rb");
    if (!f) return -1;

    if (fread(index, sizeof(Index), 1, f) != 1) {
        fclose(f);
        return -1;
    }

    fclose(f);
    return 0;
}

// Save index to file
int index_save(Index *index) {
    FILE *f = fopen(INDEX_FILE, "wb");
    if (!f) return -1;

    if (fwrite(index, sizeof(Index), 1, f) != 1) {
        fclose(f);
        return -1;
    }

    fclose(f);
    return 0;
}

// Find entry
IndexEntry* index_find(Index *index, const char *path) {
    for (int i = 0; i < index->count; i++) {
        if (strcmp(index->entries[i].path, path) == 0) {
            return &index->entries[i];
        }
    }
    return NULL;
}

// Add file
int index_add(Index *index, const char *path) {
    struct stat st;
    if (stat(path, &st) != 0) {
        return -1; // file doesn't exist
    }

    if (index->count >= MAX_ENTRIES) {
        return -1;
    }

    IndexEntry *e = &index->entries[index->count];

    strncpy(e->path, path, sizeof(e->path) - 1);
    e->path[sizeof(e->path) - 1] = '\0';

    e->mode = st.st_mode;
    e->mtime_sec = st.st_mtime;
    e->size = st.st_size;

    // fake hash (just zero for now)
    memset(e->hash.hash, 0, HASH_SIZE);

    index->count++;

    return 0;
}

// Remove file
int index_remove(Index *index, const char *path) {
    for (int i = 0; i < index->count; i++) {
        if (strcmp(index->entries[i].path, path) == 0) {
            // shift left
            for (int j = i; j < index->count - 1; j++) {
                index->entries[j] = index->entries[j + 1];
            }
            index->count--;
            return index_save(index);
        }
    }
    return -1;
}

// Status
int index_status(const Index *index) {
    for (int i = 0; i < index->count; i++) {
        printf("staged: %s\n", index->entries[i].path);
    }
    return 0;
}