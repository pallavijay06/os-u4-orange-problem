#ifndef OBJECT_H
#define OBJECT_H

#include <stdint.h>
#include <stddef.h>

#define HASH_SIZE 32
#define HASH_HEX_SIZE (HASH_SIZE * 2)

typedef enum {
    OBJ_BLOB = 1,
    OBJ_TREE = 2,
    OBJ_COMMIT = 3   // ✅ REQUIRED
} ObjectType;

typedef struct {
    uint8_t hash[HASH_SIZE];
} ObjectID;

void hash_to_hex(const ObjectID *id, char *hex_out);
int object_write(ObjectType type, const void *data, size_t len, ObjectID *id_out);
int object_read(const ObjectID *id, ObjectType *type_out, void **data_out, size_t *len_out);

#endif