#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "object.h"

// Simple commit structure
typedef struct {
    ObjectID tree;
    char message[256];
} Commit;

// Create commit
int commit_create(ObjectID tree_id, const char *message, ObjectID *commit_id_out) {
    Commit c;
    c.tree = tree_id;

    strncpy(c.message, message, sizeof(c.message) - 1);
    c.message[sizeof(c.message) - 1] = '\0';

    // ✅ now OBJ_COMMIT exists
    return object_write(OBJ_COMMIT, &c, sizeof(c), commit_id_out);
}

// Read HEAD (example function)
int head_read(ObjectID *id_out) {
    FILE *f = fopen("HEAD", "rb");
    if (!f) return -1;

    if (fread(id_out, sizeof(ObjectID), 1, f) != 1) {
        fclose(f);
        return -1;
    }

    fclose(f);
    return 0;
}