#ifndef PES_H
#define PES_H

#include "object.h"
#include "index.h"

// Directory structure
#define PES_DIR ".pes"
#define OBJECTS_DIR ".pes/objects"
#define REFS_DIR ".pes/refs"
#define HEAD_FILE ".pes/HEAD"

#endif