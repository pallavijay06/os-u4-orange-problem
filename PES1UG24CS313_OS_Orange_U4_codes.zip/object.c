#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "object.h"

// Convert binary hash → hex
void hash_to_hex(const ObjectID *id, char *hex_out) {
    for (int i = 0; i < HASH_SIZE; i++) {
        sprintf(hex_out + (i * 2), "%02x", id->hash[i]);
    }
    hex_out[HASH_HEX_SIZE] = '\0';
}

// Dummy hash
static void fake_hash(const void *data, size_t len, ObjectID *out) {
    (void)data; // suppress warning
    for (int i = 0; i < HASH_SIZE; i++) {
        out->hash[i] = (uint8_t)((i + len) % 256);
    }
}

// create dir if not exists
static void ensure_dir(const char *path) {
    mkdir(path, 0777);
}

// generate path
static void object_path(const ObjectID *id, char *path_out) {
    char hex[HASH_HEX_SIZE + 1];
    hash_to_hex(id, hex);
    sprintf(path_out, "objects/%.2s/%s", hex, hex + 2);
}

// write object
int object_write(ObjectType type, const void *data, size_t len, ObjectID *id_out) {
    (void)type;

    fake_hash(data, len, id_out);

    char hex[HASH_HEX_SIZE + 1];
    hash_to_hex(id_out, hex);

    char dir[64];
    sprintf(dir, "objects/%.2s", hex);

    ensure_dir("objects");
    ensure_dir(dir);

    char path[128];
    object_path(id_out, path);

    FILE *f = fopen(path, "wb");
    if (!f) return -1;

    fwrite(data, 1, len, f);
    fclose(f);

    return 0;
}

// read object
int object_read(const ObjectID *id, ObjectType *type_out, void **data_out, size_t *len_out) {
    (void)type_out;

    char path[128];
    object_path(id, path);

    FILE *f = fopen(path, "rb");
    if (!f) return -1;

    fseek(f, 0, SEEK_END);
    size_t size = ftell(f);
    rewind(f);

    void *buffer = malloc(size);
    if (!buffer) {
        fclose(f);
        return -1;
    }

    if (fread(buffer, 1, size, f) != size) {
        fclose(f);
        free(buffer);
        return -1;
    }

    fclose(f);

    *data_out = buffer;
    *len_out = size;

    return 0;
}