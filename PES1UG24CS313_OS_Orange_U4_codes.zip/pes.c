#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include "pes.h"

// Initialize repository
int cmd_init() {
    // create .pes directory
    if (mkdir(PES_DIR, 0755) != 0 && access(PES_DIR, F_OK) != 0) {
        perror("mkdir .pes");
        return -1;
    }

    mkdir(OBJECTS_DIR, 0755);
    mkdir(REFS_DIR, 0755);

    // create HEAD file
    if (access(HEAD_FILE, F_OK) != 0) {
        FILE *f = fopen(HEAD_FILE, "w");
        if (!f) return -1;
        fprintf(f, "refs/heads/main\n");
        fclose(f);
    }

    printf("Initialized empty PES repository\n");
    return 0;
}

// Add files
int cmd_add(int argc, char *argv[]) {
    Index index;

    if (index_load(&index) != 0) {
        index.count = 0; // start fresh if no index
    }

    for (int i = 2; i < argc; i++) {
        if (index_add(&index, argv[i]) != 0) {
            fprintf(stderr, "Failed to add %s\n", argv[i]);
        }
    }

    return index_save(&index);
}

// Status
int cmd_status() {
    Index index;

    if (index_load(&index) != 0) {
        printf("No index found\n");
        return -1;
    }

    return index_status(&index);
}

// Main CLI
int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: pes <command>\n");
        return 1;
    }

    if (strcmp(argv[1], "init") == 0) {
        return cmd_init();
    }
    else if (strcmp(argv[1], "add") == 0) {
        return cmd_add(argc, argv);
    }
    else if (strcmp(argv[1], "status") == 0) {
        return cmd_status();
    }
    else {
        printf("Unknown command\n");
        return 1;
    }
}