#ifndef COMMIT_H
#define COMMIT_H

#include "object.h"

typedef struct {
    ObjectID tree;
    ObjectID parent;
    char author[100];
    unsigned long long timestamp;
    char message[256];
} Commit;

int commit_create(const char *message, ObjectID *commit_id_out);

typedef void (*commit_walk_fn)(const ObjectID *id, const Commit *commit, void *ctx);

int commit_walk(commit_walk_fn fn, void *ctx);
int head_read(ObjectID *id_out);
int head_update(const ObjectID *new_commit);

#endif